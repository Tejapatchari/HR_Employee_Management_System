-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2023 at 03:27 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ems`
--

-- --------------------------------------------------------

--
-- Table structure for table `alogin`
--

CREATE TABLE `alogin` (
  `id` int(11) NOT NULL,
  `email` tinytext NOT NULL,
  `password` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `alogin`
--

INSERT INTO `alogin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin'),
(2, 'doreamon@nick.com', 'dora123'),
(3, 'robinson@gmail.com', 'robin123');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `nid` int(20) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `dept` varchar(100) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `pic` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `firstName`, `lastName`, `email`, `password`, `birthday`, `gender`, `contact`, `nid`, `address`, `dept`, `degree`, `pic`) VALUES
(2, 'John', 'Smith', 'john@gmail.com', '12345', '2020-09-01', 'Male', '0999999999', 1, 'Chicago', 'IT', 'Waterboy', 'images/default.jpg'),
(6, 'test', 'test', 'test@gmail.com', '1234', '2020-09-06', 'Male', '09998383737', 4, 'test', 'test', 'test', 'images/d.jpg'),
(7, 'Bill', 'Gates', 'billgates@ms.com', '1234', '2023-04-04', 'Male', '4536784321', 2, 'NY', 'MS', 'BACHELOR', 'images/clock.png'),
(8, 'Ram', 'Sethu', 'ramsethu11@gmail.com', '1234', '2000-06-06', 'Male', '4566547654', 3, 'Boston', 'social studies', 'BACHELORS', 'images/download.jpg'),
(9, 'Ryan', 'Myan', 'myanryan33@gmail.com', '1234', '2014-02-17', 'Male', '323245678', 5, 'Niles', 'Arts', 'Masters', 'images/clock.png'),
(10, 'Madison ', 'Madison Harper', 'maddy@gmail.com', '1234', '2000-02-01', 'Male', '5551234567', 6, 'Minneapolis', 'Fine arts', 'BACHELORS', 'images/no.jpg'),
(11, 'Alexander', 'Martinez', 'alexanderrm@gmail.com', '1234', '2000-02-20', 'Male', '5555555555', 7, 'Ottawa', 'psychology', 'BACHELOR', 'images/no.jpg'),
(12, 'Hannah', 'Baker', 'hannah@gmail.com', '1234', '2017-03-09', 'Female', '5559876543', 8, 'Austin', 'sociology', 'Masters', 'images/no.jpg'),
(13, 'Noah', 'Rodriguez', 'Noah99@gmail.com', '1234', '2000-12-01', 'Female', '6666666666', 9, 'nashville', 'biology', 'masters', 'images/no.jpg'),
(14, 'Isabella ', 'Eriil', 'Erillisb@gmail.com', '1234', '2023-04-12', 'Female', '4434567432', 10, 'San Antonio', 'History', 'BACHELORS', 'images/no.jpg'),
(15, 'Lucas', 'Kim', 'kimLucas@gmail.com', '1234', '2002-03-31', 'Female', '2346712890', 11, 'Vancouver', 'English', 'BACHELORS', 'images/no.jpg'),
(16, 'Emily', 'Chen', 'ChenEmily@yahoo.com', '1234', '2009-01-31', 'Female', '5432432124', 12, 'Miami', 'Computer science', 'Masters', 'images/no.jpg'),
(17, 'Ethan', 'Hernandez', 'Ethannnn@gmail.com', '1234', '2011-02-14', 'Male', '5475890000', 13, 'Pheonix', 'Fine arts', 'Masters', 'images/no.jpg'),
(18, 'Chloe', 'Lee', 'Leechloe@outlook.com', '1234', '2000-09-30', 'Female', '3245678000', 14, 'Dallas', 'Arts', 'BACHELORS', 'images/no.jpg'),
(19, 'Benjamin', 'Davis', 'Davisss@gmail.com', '1234', '1998-02-10', 'Female', '3454345544', 15, 'Seattle', 'Civil', 'Doctoral', 'images/no.jpg'),
(20, 'reck', 'hilo', 'Reckenson@yahoo.com', '1234', '2000-02-22', 'Male', '4321342345', 16, 'Chicago', 'sociology', 'masters', 'images/no.jpg'),
(21, 'Olivia', 'Wilson', 'wilsonn@gmail.com', '1234', '0000-00-00', 'Female', '3211230980', 17, 'Wichita', 'Mathematics', 'Doctoral', 'images/no.jpg'),
(22, 'William ', ' Ramirez', 'Ramirez@gmail.com', '1234', '2022-10-11', 'Male', '4540987654', 18, 'Washington', 'Business admisnistration', 'Masters', 'images/no.jpg'),
(23, 'Mia', 'Taylor', 'taylor3mia@gmail.com', '1234', '2023-03-16', 'Female', '9090909090', 19, 'Okhlama city', 'Business Analytics', 'Maters', 'images/no.jpg'),
(24, 'Daniel', 'Johnson', 'John_D@gmail.com', '1234', '2022-07-26', 'Male', '9090234567', 20, 'Charlotte', 'Information decision sciences', 'Bachelors', 'images/no.jpg'),
(25, 'Sophia', 'Ren', 'rensop@gmail.com', '1234', '2010-02-13', 'Female', '8900989090', 21, 'FLAGSTAFF', 'Research', 'Masters', 'images/no.jpg'),
(26, 'Jackson', 'Scott', 'Scott@gmail.com', '1234', '2019-07-30', 'Female', '9876789090', 22, 'Salt Lake City', 'CIVIL', 'Doctoral', 'images/no.jpg'),
(27, 'victoria', 'Palace', 'palace_victoria@yahoo.com', '1234', '2023-02-27', 'Female', '1010101019', 23, 'Denton', 'Biomedical Informatics', 'Doctoral', 'images/no.jpg'),
(28, 'Christopher', 'Nolan', 'nolan@gmail.com', '1234', '2022-10-07', 'Male', '9089090000', 24, 'Los Angeles', 'Fine arts', 'doctoral', 'images/no.jpg'),
(29, 'Awa', 'Lewis', 'Lewisawa@gmail.com', '1234', '2021-06-09', 'Male', '4747474747', 25, 'st.paul', 'social studies', 'Doctoral', 'images/no.jpg'),
(30, 'Samuel', 'Lee', 'LeeSamuel22@gmail.com', '1234', '1990-01-30', 'Male', '4444400000', 26, 'Burlington', 'Biomedical Informatics', 'BACHELORS', 'images/no.jpg'),
(31, 'Nuetella', 'Jam', 'Nuetella@yahoo.com', '1234', '2022-02-02', 'Female', '9995553210', 27, 'Hartford', 'Biophysical sciences', 'Masters', 'images/no.jpg'),
(32, 'Ryan', 'Riiyaz', 'Riyazryan@gmail.com', '1234', '2019-06-06', 'Male', '3212343222', 28, 'Salem', 'ECE', 'Masters', 'images/no.jpg'),
(33, 'Addison', 'Flores', 'Addisonsir@gmail.com', '1234', '2000-02-11', 'Female', '8594039303', 29, 'Madison', 'ECE', 'bachelors', 'images/no.jpg'),
(34, 'Samantha', 'Miller', 'millerSamantha@yahoo.com', '1234', '2000-02-22', 'Female', '90909323222', 30, 'Cinncinati', 'sociology', 'bachelors', 'images/no.jpg'),
(35, 'ciraj', 'Malik', 'malik@yahoo.com', '1234', '2000-03-12', 'Male', '9109109101', 31, 'Las Vegas', 'Chemistry', 'Bachelors', 'images/no.jpg'),
(36, 'Avery ', 'Thomas', 'Avery@gmail.com', '1234', '2017-06-06', 'Female', '10101010101', 32, 'Houston', 'biomedical sciences', 'Maters of Science', 'images/no.jpg'),
(37, 'Caleb ', 'Turner', 'Calebturner@gmail.com', '1234', '2022-12-06', 'Male', '3030303030', 33, 'Providence', 'IT', 'Masters of Science', 'images/no.jpg'),
(38, 'Joshua', 'Kim', 'Joshua111@gmail.com', '1234', '2000-01-31', 'Female', '5454545454', 34, 'Buffalo', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(39, 'Ram', 'Syam', 'ramrama@gmail.com', '1234', '2023-03-03', 'Male', '3433455333', 35, 'Miami', 'Computer science', 'Maters of Science', 'images/no.jpg'),
(40, 'Josephine ', 'Collins', 'JosephineJJ@gmail.com', '1234', '1988-07-13', 'Male', '3456666666', 36, 'New Orleans', 'Classics', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(41, 'Matthew ', 'Green', 'GreenM@gmail.com', '1234', '2022-03-10', 'Female', '1001000011', 37, 'Kansas CIty', 'ECE', 'PH.D', 'images/no.jpg'),
(42, 'Lila', 'Jones', 'jonesjones@gmail.com', '1234', '2000-11-11', 'Female', '345555555', 38, 'Rochester', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(43, 'Robert ', 'Baker', 'roberty@gmail.com', '1234', '2022-03-02', 'Male', '4322333334', 39, 'Tusla', 'Computational Neuroscience', 'PH.d', 'images/no.jpg'),
(44, 'Skylar', 'Allen', 'SkylarAA@gmail.com', '1234', '2015-02-03', 'Male', '5433975644', 40, 'Omaha', 'Finance', 'Master of Business Administration', 'images/no.jpg'),
(45, 'Ariana ', 'Grande', 'GrandeAriana@gmail.com', '1234', '1999-02-26', 'Female', '4444444422', 41, 'Hartford', 'Immunology', 'Ph.D', 'images/no.jpg'),
(46, 'Lilly', 'Scatty', 'scatty@gmail.com', '1234', '2023-02-28', 'Female', '9010504031', 42, 'Naperville', 'Human Genetics', 'Ph.D', 'images/no.jpg'),
(47, 'Issac', 'Newton', 'Issac@gmail.com', '1234', '1999-02-26', 'Male', '0000001111', 43, 'Seattle', 'Liberal Arts', 'Masters Of Liberal Arts', 'images/no.jpg'),
(48, 'Antony', 'Martin', 'MartinAntony@outlook.com', '1234', '1222-02-12', 'Male', '9722974566', 44, 'Richmond', 'Linguistics', 'Ph.D', 'images/no.jpg'),
(49, 'Jacob', 'Gargia', 'Jacob22@gmail.com', '1234', '3232-03-02', 'Male', '2342222', 45, 'Dallas', 'Computer science', 'Masters of Science', 'images/no.jpg'),
(50, 'Sofia', 'Rossi', 'Sofia@gmail.com', '1234', '2000-11-11', 'Female', '1090290098', 46, 'San Diego', 'ece', 'PH.d', 'images/no.jpg'),
(51, 'Luca ', 'Moretti', 'Luca@outlook.com', '1234', '2000-02-22', 'Male', '9009009000', 47, 'Rosemont', 'Arts', 'Masters', 'images/no.jpg'),
(52, 'Lucia', 'Romano', 'LuciaR@gmail.com', '1234', '2000-02-22', 'Female', '9878987898', 48, 'urbana-champaign', 'Mathematics', 'Ph.D', 'images/no.jpg'),
(53, 'John', 'Wick', 'Johnnn@gmail.com', '1234', '2010-11-11', 'Male', '0070070079', 49, 'Ark ville', 'Medical Physics', 'Ph.D', 'images/no.jpg'),
(54, 'Leonardo ', 'Lambardi', 'LeonL@yahoo.com', '1234', '2021-03-10', 'Female', '7890000009', 50, 'White Bridge', 'Arts', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(55, 'Eric', 'Rez', 'EricRezzie@yahoo.com', '1234', '2023-02-28', 'Male', '3243546576', 51, 'Chicago', 'Information Systems', 'Masters of Science', 'images/no.jpg'),
(56, 'Hollard', 'Gigi', 'gigi32@gmail.com', '1234', '1999-11-26', 'Male', '760916790', 52, 'Detroit', 'Computer science', 'Ph.D', 'images/no.jpg'),
(57, 'Nyon ', 'Nyon', 'NyonNyon@gmail.com', '1234', '1993-06-26', 'Male', '9999111155', 53, 'Alabama', 'Human Genetics', 'Ph.D', 'images/no.jpg'),
(58, 'Yolo', 'Singh', 'Yolo22@gmail.com', '1234', '2023-03-30', 'Male', '8889995556', 54, 'Okhlama city', 'marketing', 'BACHELORS', 'images/no.jpg'),
(59, 'Evilin', 'Rahj', 'Evilinra@gmail.com', '1234', '2023-01-26', 'Male', '5222224455', 55, 'Addison', 'Microelectronics', 'Ph.D', 'images/no.jpg'),
(60, 'Yinchu', 'Fatehi', 'Fatehii@yahoo.com', '1234', '1995-09-10', 'Female', '1234560000', 56, 'Augusta', 'Computer science', 'Masters of Science', 'images/no.jpg'),
(61, 'Raheema', 'Khan', 'Raheemadolly@yahoo.com', '1234', '2000-03-29', 'Female', '3322665544', 57, 'FLAGSTAFF', 'Chemistry', 'Doctoral', 'images/no.jpg'),
(62, 'James', 'Kyrbo', 'James@gmail.com', '1234', '2023-01-02', 'Male', '8930384956', 58, 'Lousville', 'ECE', 'Bachelors', 'images/no.jpg'),
(64, 'Ulii', 'Belagum', 'Ulli@yahoo.com', '1234', '2023-03-26', 'Female', '1200009987', 59, 'Amherst', 'Computer Engineering', 'Masters of Science', 'images/no.jpg'),
(65, 'Trelavan', 'Kib', 'Trelavan@gmail.com', '1234', '2023-01-02', 'Male', '6787878799', 60, 'San Francisco', 'Industrial Engineering', 'Masters', 'images/no.jpg'),
(66, 'Venky', 'Bhai', 'Venky@gmail.com', '1234', '2021-02-02', 'Male', '2220008889', 61, 'Berkely', 'Electronics Engineering', 'BACHELOR', 'images/no.jpg'),
(67, 'Gimmy', 'Joness', 'Joness@gmail.com', '1234', '2023-04-01', 'Female', '2211212340', 62, 'Tucson', 'Computer science', 'Ph.D', 'images/no.jpg'),
(68, 'Harry', 'Potter', 'PotterHarry@gmail.com', '1234', '2023-04-06', 'Male', '9000032177', 63, 'London', 'sociology', 'Ph.D', 'images/no.jpg'),
(69, 'Mohandas', 'Gandhi', 'Gandhi@gmail.com', '1234', '2022-10-03', 'Male', '3332221119', 64, 'New Jersey', 'psychology', 'Ph.D', 'images/no.jpg'),
(70, 'Bhagath', 'Singh', 'Bhagath@gmail.com', '1234', '2022-04-04', 'Male', '9022228887', 65, 'Ghaziabad', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(71, 'Chikni', 'Chameli', 'Chameli@gmail.com', '1234', '2022-05-08', 'Female', '8888777709', 66, 'Denver', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(72, 'Winson', 'Castle', 'Winson@gmail.com', '1234', '2003-12-28', 'Male', '1111000090', 67, 'Columbus', 'Human Genetics', 'Ph.D', 'images/no.jpg'),
(73, 'Goland', 'Polard', 'Polard@gmail.com', '1234', '2023-03-30', 'Male', '4444333322', 68, 'Omaha', 'Arts', 'Masters', 'images/no.jpg'),
(74, 'Kohli', 'Chowkamaar', 'Kohli@gmail.com', '1234', '2022-11-08', 'Male', '3333321234', 69, 'Memphis', 'Finance', 'Ph.D', 'images/no.jpg'),
(75, 'Reddyji', 'Eliane', 'Reddy@gmail.com', '1234', '2023-04-01', 'Female', '5422976544', 70, 'Portland', 'sociology', 'Doctoral', 'images/no.jpg'),
(76, 'Ganesh', 'Ji', 'Ganeshhh@gmail.com', '1234', '1983-07-06', 'Male', '3330003303', 71, 'Oreano City', 'sociology', 'Ph.D', 'images/no.jpg'),
(77, 'Ejjer', 'Gajjar', 'Gajar@yahoo.com', '1234', '2000-05-31', 'Male', '4432222222', 72, 'Louisvillle', 'ECE', 'Masters', 'images/no.jpg'),
(78, 'Ramika', 'Sen', 'ramika@gmail.com', '1234', '2023-04-13', 'Female', '9090008888', 73, 'Somerville', 'Fine arts', 'Ph.D', 'images/no.jpg'),
(79, 'Hershey', 'Syurup', 'hersheyy@gmail.com', '1234', '2023-01-24', 'Female', '3232344444', 74, 'Cambridge', 'Fine arts', 'BACHELORS', 'images/no.jpg'),
(80, 'Donna', 'Jermiah', 'Donnaa@yahoo.com', '1234', '2000-12-12', 'Female', '4433232346', 75, 'Huntley', 'CIVIL', 'Masters of Science', 'images/no.jpg'),
(81, 'Ion', 'James', 'Ion@outlook.com', '1234', '2001-11-12', 'Female', '8900009934', 76, 'Milawakee', 'Cinema and media Studies', 'Ph.D', 'images/no.jpg'),
(82, 'Yoyohoney', 'Singh', 'Yoyohoney@gmail.com', '1234', '2000-09-09', 'Female', '9099909999', 77, 'Orlando', 'Biomedical Informatics', 'Ph.D', 'images/no.jpg'),
(83, 'Bajji', 'Bujji', 'bajji@gmail.com', '1234', '2003-11-12', 'Female', '4545422202', 78, 'Montreal', 'Computer science', 'Ph.D', 'images/no.jpg'),
(84, 'Sweety', 'Pie', 'Sweety@gmail.com', '1234', '2003-12-12', 'Female', '3443212334', 79, 'Ontario', 'biomedical sciences', 'Masters', 'images/no.jpg'),
(85, 'Chandrika', 'Ren', 'Chandrika@outlook.com', '1234', '2001-11-12', 'Female', '4124125632', 80, 'Denver', 'Chemistry', 'Ph.D', 'images/no.jpg'),
(86, 'Boi', 'Choi', 'Boichoi@outlook.com', '1234', '2023-03-27', 'Other', '1245021235', 81, 'Katy', 'Information Systems', 'Masters of Science', 'images/no.jpg'),
(87, 'Rocky', 'Bhai', 'Rockykgf@gmail.com', '1234', '2000-12-12', 'Male', '898234567', 82, 'Bengaluru', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(88, 'Inayath', 'Khalil', 'Inayath@gmail.com', '1234', '2000-01-01', 'Male', '1256444400', 83, 'Dubai', 'psychology', 'Ph.D', 'images/no.jpg'),
(89, 'Sunday', 'Roy', 'Sunday@gmail.com', '1234', '2009-11-21', 'Male', '9342235322', 84, 'Lagos', 'ECE', 'Masters', 'images/no.jpg'),
(90, 'Friday', 'Baba', 'Friday@gmail.com', '1234', '2005-05-05', 'Male', '4562874125', 85, 'Abuja', 'sociology', 'Masters', 'images/no.jpg'),
(91, 'Bin', 'Mirginham', 'BinM@gmail.com', '1234', '2004-04-04', 'Female', '4578125478', 86, 'Minnesota', 'Information Systems', 'BACHELORS', 'images/no.jpg'),
(92, 'Joy', 'Joy', 'JOYJOY@gmail.com', '1234', '2008-01-02', 'Female', '1254541254', 87, 'Seattle', 'Biology', 'BACHELORS', 'images/no.jpg'),
(93, 'Jimmy', 'Keilley', 'Jimmy@outlook.com', '1234', '2006-06-06', 'Female', '4521536021', 88, 'NewBedfordshire', 'Arts', 'Masters', 'images/no.jpg'),
(94, 'Vinny', 'Kam', 'Vinny@gmail.com', '1234', '2000-12-12', 'Female', '1254126398', 89, 'London', 'Architecture', 'Masters in Architecture', 'images/no.jpg'),
(95, 'Zepnix', 'Zep', 'Zepnix@gmail.com', '1234', '2004-12-12', 'Male', '4515478965', 90, 'India', 'Physiotherapy', 'BACHELORS', 'images/no.jpg'),
(96, 'Sai', 'Prashanth', 'sai2@gamil.com', '1234', '2000-04-27', 'Male', '4521458796', 91, 'Rockshide', 'Supplychain and logistics management', 'Masters', 'images/no.jpg'),
(97, 'Olaf', 'Hassan', 'Olaf@gmail.com', '1234', '2001-02-02', 'Female', '4562001012', 92, 'Chicago', 'Industrial Engineering', 'Maters of Science', 'images/no.jpg'),
(98, 'Aditya', 'Malniggaa', 'Anigga@nigeria.com', '1234', '2001-12-12', 'Male', '4563214563', 93, 'Clinton', 'Biophysical sciences', 'Ph.D', 'images/no.jpg'),
(99, 'Trousa', 'Lunin', 'Trousa@gmail.com', '1234', '1999-01-31', 'Other', '4521000000', 94, 'Franklin', 'Information decision sciences', 'BACHELORS', 'images/no.jpg'),
(100, 'Senorita', 'Panchama', 'SenoritaM@gmail.com', '1234', '2003-09-09', '', '4521000320', 95, 'Tempe', 'Business admisnistration', 'Masters', 'images/no.jpg'),
(101, 'Privol', 'Animol', 'Privol@yahoomail.com', '1234', '1999-05-05', 'Female', '3000569991', 96, 'Springlfield', 'Supplychain and logistics management', 'Masters', 'images/no.jpg'),
(102, 'Ulifath', 'Franky', 'Frank@gmail.com', '1234', '2000-08-01', '', '7895741452', 97, 'Georgetown', 'MLS', 'Master of Library Science', 'images/no.jpg'),
(103, 'Kokome', 'Jin', 'Kokome@gmail.com', '1234', '1998-02-12', 'Female', '6447474155', 98, 'Lebanon', 'MSLS', 'Master of Library Science', 'images/no.jpg'),
(104, 'Jin', 'Jin', 'JINJIN@gmail.com', '1234', '1999-09-09', 'Male', '3030214569', 99, 'Arlington', 'Arts', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(105, 'Raheem', 'Bhai', 'Raheem@gmail.com', '1234', '1992-09-03', 'Male', '3828298899', 100, 'Beaumont', 'Computer science', 'Masters of Science', 'images/no.jpg'),
(106, 'Winchow', 'Joe', 'Winchow@gmail.com', '1234', '1993-03-03', 'Male', '5245212356', 101, 'Tyler', 'Business Analytics', 'Masters of Science', 'images/no.jpg'),
(107, 'Volatina', 'Fuyima', 'Volatina@gmail.com', '1234', '1995-04-04', 'Female', '4343090876', 102, 'Alabama', 'Computational Neuroscience', 'Doctoral', 'images/no.jpg'),
(108, 'Joy', 'James', 'Joy@gmail.com', '1234', '1999-09-09', 'Male', '2563012302', 103, 'urbana-champaign', 'Fine arts', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(109, 'Raj', 'Syam', 'Syamraj@yahoomail.com', '1234', '2000-04-04', 'Male', '6352141414', 104, 'Vancouver', 'Information decision sciences', 'Masters', 'images/no.jpg'),
(110, 'Jennifer', 'Pel', 'Jenny@gmail.com', '1234', '2000-10-10', 'Female', '2314569874', 105, 'waco', 'Immunology', 'Doctoral', 'images/no.jpg'),
(111, 'Daniels', 'James', 'JD@gmail.com', '1234', '1899-09-10', 'Other', '2312321798', 106, 'Madison', 'Architecture', 'Masters in Architecture', 'images/no.jpg'),
(112, 'Jamy', 'Kaet', 'Jamy@gmail.com', '1234', '2008-09-09', 'Female', '3201230158', 107, 'nashville', 'ECE', 'Doctoral', 'images/no.jpg'),
(113, 'Jason', 'Zheng', 'JasonZ@gmail.com', '1234', '2020-02-20', 'Male', '3693693693', 108, 'Aromville', 'Business Analytics', 'Masters of Science', 'images/no.jpg'),
(114, 'George', 'Kol', 'Geroge@gmail.com', '1234', '2002-02-02', 'Female', '14785236985', 109, 'San Diego', 'Cinema and media Studies', 'Ph.D', 'images/no.jpg'),
(115, 'Shalini', 'Jaya', 'Shantij@yahoomail.com', '1234', '1999-03-04', 'Female', '323232323', 110, 'Jackson', 'supplychain management', 'Masters', 'images/no.jpg'),
(116, 'Nayrobi', 'Jaam', 'nayrobi@yahoomail.com', '1234', '2000-12-12', 'Female', '3652652145', 111, 'Galveston', 'Engineering Management', 'Masters', 'images/no.jpg'),
(117, 'Nijameshwar', 'Roy', 'Nijam@gmail.com', '1234', '1988-04-03', 'Female', '3025632563', 112, 'Orlando', 'IT', 'Masters of Science', 'images/no.jpg'),
(118, 'Laila', 'Khan', 'KhanL@gmail.com', '1234', '2007-07-07', 'Female', '4567896542', 113, 'Charlotte', 'Fine arts', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(119, 'Anupama', 'Param', 'Anupamap@yahoomail.com', '1234', '2000-02-02', 'Female', '7412589632', 114, 'NewBedfordshire', 'sociology', 'Doctoral', 'images/no.jpg'),
(120, 'Shakira', 'Shakira', 'Shakiras@gmail.com', '1234', '1999-05-31', 'Female', '3090920192', 115, 'Richmond', 'Information decision sciences', 'Doctoral', 'images/no.jpg'),
(121, 'Honey', 'Danny', 'honeyd@gmail.com', '1234', '2000-05-30', '', '3098900987', 116, 'Rockshide', 'Business Analytics', 'Masters of Science', 'images/no.jpg'),
(122, 'Victoria', 'Zen', 'victoria@gmail.com', '1234', '1999-05-29', 'Male', '32563256321', 117, 'Centerville', 'Fine arts', 'Doctoral', 'images/no.jpg'),
(123, 'Kano', 'Kano', 'Kano@gmail.com', '1234', '1999-02-25', 'Male', '4159951235', 118, 'Sugar Land', 'social studies', 'BACHELORS', 'images/no.jpg'),
(124, 'Rein', 'Raj', 'Reinn@gmail.com', '1234', '2002-03-03', 'Male', '12343212209', 119, 'Cinncinati', 'Biophysical sciences', 'Masters', 'images/no.jpg'),
(125, 'Chanda', 'Chanda', 'Chandachanda@gmail.com', '1234', '1990-12-21', '', '3224567890', 120, 'Waco', 'MSLS', 'Master of Library Science', 'images/no.jpg'),
(126, 'Rashmika', 'Mandanna', 'Mandanna@outlook.com', '1234', '2011-11-11', 'Female', '4464785632', 120, 'Lafayette', 'biomedical sciences', 'Doctoral', 'images/no.jpg'),
(127, 'Sen', 'Ji', 'Sen@yahoomail.com', '1234', '1990-12-31', 'Female', '3213879098', 121, 'Baltimore', 'MLIS', 'Master of Library Science', 'images/no.jpg'),
(128, 'Sofia', 'Steph', 'Step@gmail.com', '1234', '2000-02-02', 'Female', '2332456789', 121, 'Rochester', 'ECE', 'Doctoral', 'images/no.jpg'),
(129, 'Jake', 'Beyoj', 'Jakee@yahoo.com', '1234', '1992-01-01', 'Male', '4569874563', 122, 'Cambridge', 'Computer science', 'Masters of Science', 'images/no.jpg'),
(130, 'Diljit ', 'Dosanjh', 'Diljit@yahoomail.com', '1234', '2010-06-04', 'Male', '2345678976', 123, 'Providence', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(131, 'Tina', 'Flor', 'tina@gmail.com', '1234', '1899-08-08', '', '4239090876', 124, 'Tusla', 'Biophysical sciences', 'BACHELORS', 'images/no.jpg'),
(132, 'Ramsai', 'RAM', 'sairam@gmail.com', '1234', '2011-02-05', 'Male', '5444654321', 125, 'Georgetown', 'Business Management', 'Executive Masters', 'images/no.jpg'),
(133, 'Lakshmi', 'Bhavani', 'Lakshmi@gmail.com', '1234', '1999-12-04', 'Female', '6534432122', 126, 'New Hampshire', 'Biomedical Informatics', 'Ph.D', 'images/no.jpg'),
(134, 'Yamaha', 'Ban', 'Yamaha@gmail.com', '1234', '2003-02-20', 'Male', '3223789098', 127, 'Huntsville', 'Biology', 'Doctoral', 'images/no.jpg'),
(135, 'Gokul', 'Raama', 'Gokul@gmail.com', '1234', '1992-02-02', 'Male', '7865436567', 128, 'Georgetown', 'Biomedical Informatics', 'Ph.D', 'images/no.jpg'),
(136, 'Kilaer', 'Uil', 'Kilaer@gmail.com', '1234', '2000-02-03', 'Female', '8799090999', 129, 'Folland', 'Arts', 'Ph.D', 'images/no.jpg'),
(137, 'Jakes', 'Joy', 'Jakess@gmail.com', '1234', '1999-12-12', 'Male', '7865439283', 130, 'Centerville', 'Computer science', 'Masters of Science', 'images/no.jpg'),
(138, 'Gimmo', 'Hoie', 'Gimmo@gmail.com', '1234', '1999-03-04', 'Male', '5467898999', 131, 'Tampa', 'biomedical sciences', 'Ph.D', 'images/no.jpg'),
(139, 'Damy', 'Jolo', 'Damy@gmail.com', '1234', '2004-02-04', 'Other', '4442223211', 132, 'Huntley', 'Business Analytics', 'Masters of Science', 'images/no.jpg'),
(140, 'Don', 'Bosco', 'Donbos@gmail.com', '1234', '2003-02-09', 'Male', '4543309009', 133, 'Tyler', 'Computer science', 'Ph.D', 'images/no.jpg'),
(141, 'Luka', 'Chuppi', 'Lucas@outlook.com', '1234', '2000-03-03', 'Female', '5433298766', 134, 'Addison', 'Biophysical sciences', 'Ph.D', 'images/no.jpg'),
(142, 'Karthik ', 'Aaryan', 'KarthikAryan@gmail.com', '1234', '1999-05-05', 'Male', '0987654567', 135, 'Atlanta', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(143, 'Anbae', 'Nanbae', 'anbae@gmail.com', '1234', '2000-11-11', '', '3233987654', 136, 'Louisvillle', 'ECE', 'BACHELORS', 'images/no.jpg'),
(144, 'Nann', 'Nanna', 'nann@gmail.com', '1234', '1999-12-02', '', '2345654321', 137, 'Omaha', 'Computer science', 'Masters of Science', 'images/no.jpg'),
(145, 'Teja', 'Poha', 'Tejapoha@gmail.com', '1234', '2000-01-14', 'Male', '8733987654', 138, 'Charlotte', 'Information Systems', 'Maters of Science', 'images/no.jpg'),
(146, 'Ayan', 'Rodriguez', 'Ayaan@gmail.com', '1234', '2005-05-05', 'Male', '3232345555', 139, 'Rochester', 'History', 'Doctoral', 'images/no.jpg'),
(147, 'Vaadivasal', 'JI', 'vaadi@gmail.com', '1234', '2004-04-04', '', '9876567676', 140, 'Vancouver', 'sociology', 'Doctoral', 'images/no.jpg'),
(148, 'Yendadha', 'Ram', 'Yendadha@gmail.com', '1234', '2009-09-09', '', '4325679999', 141, 'Lafayette', 'Biology', 'Ph.D', 'images/no.jpg'),
(149, 'Das', 'Khan', 'daska@gmail.com', '1234', '2005-05-05', '', '8766666666', 142, 'Madison', 'Fine arts', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(150, 'Dhoni', 'Mahendra', 'Mahendra@gmail.com', '1234', '1999-03-04', 'Male', '3435678876', 143, 'North Lake', 'Information decision sciences', 'BACHELORS', 'images/no.jpg'),
(151, 'Nantha', 'Saran', 'nantha333@gmail.com', '1234', '1999-04-04', 'Male', '535433444', 144, 'Tampa', 'ECE', 'BACHELORS', 'images/no.jpg'),
(152, 'Nehgak', 'Joye', 'Neghak@gmail.com', '1234', '1994-04-04', 'Male', '5434567898', 145, 'Huntsville', 'Computer science', 'Doctoral', 'images/no.jpg'),
(153, 'Machima', 'Danniel', 'Machi@gmail.com', '1234', '1881-08-08', 'Male', '3345432213', 146, 'Tucson', 'Arts', 'Masters', 'images/no.jpg'),
(154, 'George', 'Killi', 'George@gmail.com', '1234', '1991-06-06', 'Male', '2357475689', 147, 'Chicago', 'Business Analytics', 'Ph.D', 'images/no.jpg'),
(155, 'Meesayya', 'Murukku', 'Meesayya@gmail.com', '1234', '2001-02-22', 'Female', '8734323456', 148, 'Rosemont', 'biomedical sciences', 'Doctoral', 'images/no.jpg'),
(156, 'Kaadhalram', 'vedham', 'Kaadhal@gmail.com', '1234', '2000-12-12', 'Male', '7876543261', 149, 'Tusla', 'Cinema and media Studies', 'Masters', 'images/no.jpg'),
(157, 'Saiyon', 'Quil', 'Saiyo@gmail.com', '1234', '2000-12-12', '', '4328765678', 150, 'Galveston', 'Computer science', 'Masters', 'images/no.jpg'),
(158, 'Yok', 'Choi', 'Yokchoi@gmail.com', '1234', '1999-01-01', 'Male', '6768767898', 151, 'Rockshide', 'CIVIL', 'Ph.D', 'images/no.jpg'),
(159, 'Boster', 'Kore', 'Boster@yahoo.com', '1234', '2000-11-01', 'Female', '5748987543', 152, 'Houston', 'Fine arts', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(160, 'Anjali', 'Anjalii', 'Anjalianja@gmail.com', '1234', '0000-00-00', 'Female', '434758438', 153, 'Dallas', 'sociology', 'Doctoral', 'images/no.jpg'),
(161, 'Aadhi', 'Aksai', 'Aadhi@gmail.com', '1234', '1999-12-04', 'Male', '6754387654', 154, 'Ghaziabad', 'Arts', 'BACHELORS', 'images/no.jpg'),
(162, 'Faces', 'Kiladi', 'Faces@gmail.com', '1234', '2001-12-21', 'Female', '352554321', 155, 'Kansas CIty', 'Computer science', 'Ph.D', 'images/no.jpg'),
(163, 'Jilleer', 'hiller', 'Jilleer@gmail.com', '1234', '2001-02-28', 'Female', '4324322345', 156, 'Omaha', 'Computer science', 'Maters of Science', 'images/no.jpg'),
(164, 'Huehue', 'Hue', 'huehue@gmail.com', '1234', '2000-09-09', 'Male', '8943234567', 157, 'Huntley', 'Cinema and media Studies', 'Masters', 'images/no.jpg'),
(165, 'DHARMAM', 'TIRU', 'Dharmam@gmail.com', '1234', '2000-04-23', 'Male', '234254321', 158, 'nashville', 'biomedical sciences', 'BACHELORS', 'images/no.jpg'),
(166, 'Aadhij', 'Jore', 'Aadhi33@gmail.com', '1234', '2000-03-03', 'Male', '4321234567', 159, 'Franklin', 'Fine arts', 'Masters', 'images/no.jpg'),
(167, 'Jiley', 'Ram', 'Jiley@gmail.com', '1234', '2000-04-05', 'Female', '3454345678', 160, 'Tucson', 'Fine arts', 'Masters of Science', 'images/no.jpg'),
(168, 'Facesss', 'Royai', 'Facess3@yahoomail.com', '1234', '2000-12-31', '', '4758457685', 161, 'Buffalo', 'sociology', 'Masters of Science', 'images/no.jpg'),
(169, 'Leonardomu', 'Danniel', 'dannn@gmail.com', '1234', '1999-06-07', 'Female', '7895471235', 162, 'Katy', 'History', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(170, 'Pkiok', 'you', 'pk@gmail.com', '1234', '2000-05-09', 'Male', '4559258741', 163, 'Cambridge', 'Finance', 'Doctoral', 'images/no.jpg'),
(171, 'Ronaldo', 'Deinver', 'Ronaldo@gmail.com', '1234', '2332-02-28', 'Male', '9876543212', 164, 'Ark ville', 'Fine arts', 'Doctoral', 'images/no.jpg'),
(172, 'Denji', 'hun', 'denji@gmail.com', '1234', '2000-07-07', 'Male', '785678765', 165, 'Tampa', 'Architecture', 'Masters in Architecture', 'images/no.jpg'),
(173, 'Priyanka', 'Woil', 'Priyanka@gmail.com', '1234', '2000-04-20', 'Male', '3214890987', 166, 'Franklin', 'ECE', 'Doctoral', 'images/no.jpg'),
(174, 'Fathima', 'Giles', 'fathima@gmail.com', '1234', '2001-05-05', '', '898764543', 167, 'Memphis', 'Information Systems', 'Masters of Science', 'images/no.jpg'),
(175, 'Onsitegile', 'Gandhii', 'onsite@gmail.com', '1234', '2000-04-23', '', '4938938987', 168, 'Richmond', 'ECE', 'BACHELORS', 'images/no.jpg'),
(176, 'saiprakash', 'Fuy', 'saip@gmail.com', '1234', '1995-12-12', '', '5647389829', 169, 'Huntsville', 'Business Analytics', 'Maters of Science', 'images/no.jpg'),
(177, 'Nayanathara', 'Jolly', 'Nayanathara@gmail.com', '1234', '2000-02-12', 'Female', '3432344322', 170, 'Salem', 'Finance', 'Masters ', 'images/no.jpg'),
(178, 'Vishnu', 'Vishal', 'vishnuv@gmail.com', '1234', '2001-12-12', 'Male', '8787878787', 171, 'Boston', 'Arts', 'Masters of Science', 'images/no.jpg'),
(179, 'Chella', 'Kutty', 'Chel@gmail.com', '1234', '2000-12-03', '', '2342122332', 172, 'Clinton', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(180, 'Oreain', 'Tribune', 'Oreain@gmail.com', '1234', '1999-12-12', 'Male', '8789889892', 173, 'Tempe', 'Arts', 'Doctoral', 'images/no.jpg'),
(181, 'Boni', 'sivu', 'sivu@gmail.com', '1234', '2000-09-09', 'Female', '7654321234', 174, 'indiana', 'Business admisnistration', 'BACHELORS', 'images/no.jpg'),
(182, 'Dulquer', 'Salman', 'dulquer@gmail.com', '1234', '1998-03-04', '', '4567654321', 175, 'indiana', 'dance', 'BACHELORS', 'images/no.jpg'),
(183, 'emilyy', 'Das', 'emily@gmail.com', '1234', '1966-02-09', '', '5332345675', 176, 'Wichita', 'Computer science', 'Maters of Science', 'images/no.jpg'),
(184, 'Dollyji', 'Damaka', 'Dollyji@gmail.com', '1234', '1998-05-05', '', '4345676543', 177, 'Franklin', 'MLIS', 'Master of Library Science', 'images/no.jpg'),
(185, 'Remo', 'Holla', 'remo@gmail.com', '1234', '1998-07-07', '', '5432123456', 178, 'Rochester', 'Research', 'Masters', 'images/no.jpg'),
(186, 'Sai', 'Ram', 'saiRammm@gmail.com', '1234', '1995-04-04', 'Male', '4223431234', 179, 'Tyler', 'Computer science', 'Masters of Science', 'images/no.jpg'),
(187, 'Polardino', 'Polard', 'Polardinoo@gmail.com', '1234', '1990-02-02', 'Male', '878987432', 180, 'Dallas', 'Supplychain and logistics management', 'BACHELORS', 'images/no.jpg'),
(188, 'Harri', 'Godse', 'Harri@gmail.com', '1234', '2019-01-04', 'Female', '7584987654', 181, 'Warrenville', 'ECE', 'Masters of Science', 'images/no.jpg'),
(189, 'Baby', 'Doll', 'Babydoll@gmail.com', '1234', '2000-03-12', 'Female', '4324233456', 182, 'Errenville', 'Biology', 'Masters', 'images/no.jpg'),
(190, 'Ruthvij', 'Matare', 'Ruthvij@gmail.com', '1234', '2000-02-03', 'Male', '5421234567', 183, 'Richmond', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(191, 'Shree', 'parida', 'shree2@gmail.com', '1234', '1999-12-05', 'Female', '9879879879', 184, 'Los Angeles', 'Arts', 'Ph.D', 'images/no.jpg'),
(192, 'Jinna', 'Bhai', 'Jinnabhai@gmail.com', '1234', '2021-12-12', 'Male', '9875431789', 185, 'Washington', 'supplychain management', 'Masters', 'images/no.jpg'),
(193, 'faimaaa', 'rathod', 'faima@gmail.com', '1234', '1991-03-02', 'Female', '7877235644', 186, 'Salt Lake City', 'Finance', 'Ph.D', 'images/no.jpg'),
(194, 'Kilbil', 'Pandey', 'kilbil@gmail.com', '1234', '2002-03-31', 'Male', '4214353987', 187, 'Miami', 'Supplychain and logistics management', 'Doctoral', 'images/no.jpg'),
(195, 'Ginger', 'Jolo', 'gigg@gmail.com', '1234', '2003-12-08', 'Male', '7584837546', 188, 'Galveston', 'Human Genetics', 'Doctoral', 'images/no.jpg'),
(196, 'Honeyrose', 'Mal', 'honeyrose@gmail.com', '1234', '2000-01-31', 'Male', '5423432345', 189, 'Denver', 'Cinema and media Studies', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(197, 'Pradeep', 'Ranga', 'Pradeep@gmail.com', '1234', '2001-02-03', 'Male', '8744384756', 190, 'Salem', 'sociology', 'Masters', 'images/no.jpg'),
(198, 'Nejai', 'Assam', 'Nejai@gmail.com', '1234', '1999-08-09', 'Male', '8738787878', 191, 'Denton', 'Arts', 'Masters', 'images/no.jpg'),
(199, 'Alexandraa', 'Nannaa', 'Alexander@gmail.com', '1234', '2009-06-06', 'Male', '989898989', 192, 'Franklin', 'Computer science', 'Masters of Science', 'images/no.jpg'),
(200, 'Dokiji', 'Laila', 'doki@gmail.com', '1234', '2000-11-11', 'Male', '3245678900', 193, 'Houston', 'Fine arts', 'Doctoral', 'images/no.jpg'),
(201, 'Sachin', 'Tendulkar', 'Sachin@gmail.com', '1234', '2010-08-08', 'Male', '9878987898', 194, 'Las Vegas', 'Computer science', 'Masters', 'images/no.jpg'),
(202, 'Uini', 'Kinin', 'Uini@gmail.com', '1234', '2222-02-22', 'Female', '543234543', 195, 'Rockshide', 'Computer science', 'Masters', 'images/no.jpg'),
(203, 'Bolo', 'Fam', 'Bolo@gmail.com', '1234', '2002-03-02', 'Male', '9898989866', 196, 'Alabama', 'Biomedical Informatics', 'Masters ', 'images/no.jpg'),
(204, 'Tulip', 'Flor', 'Tulip@gmail.com', '1234', '2002-03-22', 'Female', '4378685942', 197, 'FLAGSTAFF', 'Information Systems', 'BACHELORS', 'images/no.jpg'),
(205, 'Sunny', 'Rose', 'Sunnyrose@gmail.com', '1234', '1996-06-06', 'Female', '7689090909', 198, 'Huntsville', 'ECE', 'Doctoral', 'images/no.jpg'),
(206, 'Diana', 'Moreano', 'Diana@gmail.com', '1234', '2009-11-11', 'Female', '7648789090', 199, 'Atlanta', 'Fine arts', 'Master of Arts Program in Humanities', 'images/no.jpg'),
(207, 'Wichin', 'Robin', 'Wirobin@gmail.com', '1234', '1990-12-12', 'Other', '8909076545', 200, 'Chicago', 'Supplychain and logistics management', 'Ph.D', 'images/no.jpg'),
(208, 'Mark', 'Zuuck', 'mk@facebpook.vom', '1234', '2023-04-07', 'Male', '1234567890', 123566, 'IL', 'Sales', 'Dropout', 'images/no.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `employee_leave`
--

CREATE TABLE `employee_leave` (
  `id` int(11) DEFAULT NULL,
  `token` int(11) NOT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `reason` char(100) DEFAULT NULL,
  `status` char(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employee_leave`
--

INSERT INTO `employee_leave` (`id`, `token`, `start`, `end`, `reason`, `status`) VALUES
(2, 1, '2020-09-03', '2020-09-05', 'COVID-19', 'Cancelled'),
(7, 2, '2023-04-03', '2023-04-05', 'Fever', 'Cancelled'),
(2, 3, '2020-09-10', '2020-09-12', 'May Lagnat', 'Approved'),
(48, 4, '2023-04-13', '2023-04-14', 'Stomach Ache', 'Cancelled'),
(28, 5, '2023-04-17', '2023-04-18', 'Back ache', 'Approved'),
(45, 6, '2023-05-01', '2023-05-03', 'Medical Emergency', 'Approved'),
(13, 7, '2023-04-10', '2023-04-18', 'Typhoid', 'Approved'),
(44, 8, '2023-04-13', '2023-04-19', 'Dengue', 'Approved'),
(18, 9, '2023-04-07', '2023-04-11', 'Chicken pox', 'Cancelled'),
(39, 10, '2023-04-26', '2023-04-28', 'Flu', 'Approved'),
(2, 11, '2023-04-27', '2023-04-28', 'Nausea', 'Approved'),
(15, 12, '2023-04-26', '2023-04-28', 'Headache', 'Approved'),
(2, 13, '2023-04-18', '2023-04-19', 'Fever', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `pid` int(11) NOT NULL,
  `eid` int(11) DEFAULT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `subdate` date DEFAULT '0000-00-00',
  `mark` int(11) NOT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`pid`, `eid`, `pname`, `duedate`, `subdate`, `mark`, `status`) VALUES
(1, 2, 'Junkyard', '2020-09-26', '2020-09-04', 1, 'Submitted'),
(8, 20, 'RichJunk', '2023-04-07', '2023-04-06', 0, 'Due'),
(9, 50, 'Pictories', '2023-03-09', '2023-04-27', 0, 'Submitted'),
(10, 33, 'Funnylink', '2023-04-11', '2023-04-12', 0, 'Submitted'),
(11, 12, 'Bizard', '2023-03-01', '2023-03-02', 0, 'Submitted'),
(12, 10, 'Humories', '2023-03-02', '2023-03-03', 0, 'Submitted'),
(13, 22, 'CodeLac', '2023-02-06', '2023-02-08', 0, 'Submitted'),
(14, 29, 'Salarify', '2023-04-26', '2023-04-27', 0, 'Due'),
(15, 15, 'holajame', '2023-04-25', '2023-04-27', 0, 'Submitted'),
(16, 32, 'Wittter', '2023-04-17', '2023-04-27', 0, 'Submitted'),
(17, 18, 'Java', '2022-12-07', '2023-04-27', 0, 'Submitted'),
(18, 50, 'Javaint', '2023-04-27', '0000-00-00', 0, 'Due'),
(19, 2, 'JunkBob', '2023-04-27', '0000-00-00', 0, 'Due');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `eid` int(11) NOT NULL,
  `points` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`eid`, `points`) VALUES
(2, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(11, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(18, 0),
(19, 0),
(20, 0),
(21, 0),
(22, 0),
(23, 0),
(24, 0),
(25, 0),
(26, 0),
(27, 0),
(28, 0),
(29, 0),
(30, 0),
(31, 0),
(32, 0),
(33, 0),
(34, 0),
(35, 0),
(36, 0),
(37, 0),
(38, 0),
(39, 0),
(40, 0),
(41, 0),
(42, 0),
(43, 0),
(44, 0),
(45, 0),
(46, 0),
(47, 0),
(48, 0),
(49, 0),
(50, 0),
(51, 0),
(52, 0),
(53, 0),
(54, 0),
(55, 0),
(56, 0),
(57, 0),
(58, 0),
(59, 0),
(60, 0),
(61, 0),
(62, 0),
(64, 0),
(65, 0),
(66, 0),
(67, 0),
(68, 0),
(69, 0),
(70, 0),
(71, 0),
(72, 0),
(73, 0),
(74, 0),
(75, 0),
(76, 0),
(77, 0),
(78, 0),
(79, 0),
(80, 0),
(81, 0),
(82, 0),
(83, 0),
(84, 0),
(85, 0),
(86, 0),
(87, 0),
(88, 0),
(89, 0),
(90, 0),
(91, 0),
(92, 0),
(93, 0),
(94, 0),
(95, 0),
(96, 0),
(97, 0),
(98, 0),
(99, 0),
(100, 0),
(101, 0),
(102, 0),
(103, 0),
(104, 0),
(105, 0),
(106, 0),
(107, 0),
(108, 0),
(109, 0),
(110, 0),
(111, 0),
(112, 0),
(113, 0),
(114, 0),
(115, 0),
(116, 0),
(117, 0),
(118, 0),
(119, 0),
(120, 0),
(121, 0),
(122, 0),
(123, 0),
(124, 0),
(125, 0),
(126, 0),
(127, 0),
(128, 0),
(129, 0),
(130, 0),
(131, 0),
(132, 0),
(133, 0),
(134, 0),
(135, 0),
(136, 0),
(137, 0),
(138, 0),
(139, 0),
(140, 0),
(141, 0),
(142, 0),
(143, 0),
(144, 0),
(145, 0),
(146, 0),
(147, 0),
(148, 0),
(149, 0),
(150, 0),
(151, 0),
(152, 0),
(153, 0),
(154, 0),
(155, 0),
(156, 0),
(157, 0),
(158, 0),
(159, 0),
(160, 0),
(161, 0),
(162, 0),
(163, 0),
(164, 0),
(165, 0),
(166, 0),
(167, 0),
(168, 0),
(169, 0),
(170, 0),
(171, 0),
(172, 0),
(173, 0),
(174, 0),
(175, 0),
(176, 0),
(177, 0),
(178, 0),
(179, 0),
(180, 0),
(181, 0),
(182, 0),
(183, 0),
(184, 0),
(185, 0),
(186, 0),
(187, 0),
(188, 0),
(189, 0),
(190, 0),
(191, 0),
(192, 0),
(193, 0),
(194, 0),
(195, 0),
(196, 0),
(197, 0),
(198, 0),
(199, 0),
(200, 0),
(201, 0),
(202, 0),
(203, 0),
(204, 0),
(205, 0),
(206, 0),
(207, 0),
(208, 0);

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` int(11) NOT NULL,
  `base` int(11) NOT NULL,
  `bonus` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `base`, `bonus`, `total`) VALUES
(2, 500, 0, 500),
(6, 1000, 0, 1000),
(7, 200000000, 0, 200000000),
(8, 1222, 0, 1222),
(9, 2332, 0, 2332),
(10, 34343, 0, 34343),
(11, 34343, 0, 34343),
(12, 3333, 0, 3333),
(13, 34343, 0, 34343),
(14, 4321, 0, 4321),
(15, 4322, 0, 4322),
(16, 3242, 0, 3242),
(17, 333, 0, 333),
(18, 43433, 0, 43433),
(19, 20000, 0, 20000),
(20, 43423, 0, 43423),
(21, 33333, 0, 33333),
(22, 43222, 0, 43222),
(23, 43433, 0, 43433),
(24, 89898, 0, 89898),
(25, 90000, 0, 90000),
(26, 44444, 0, 44444),
(27, 99999, 0, 99999),
(28, 900000, 0, 900000),
(29, 444, 0, 444),
(30, 9090, 0, 9090),
(31, 444433, 0, 444433),
(32, 94944, 0, 94944),
(33, 3333, 0, 3333),
(34, 3333, 0, 3333),
(35, 33333, 0, 33333),
(36, 3333333, 0, 3333333),
(37, 44334, 0, 44334),
(38, 70000, 0, 70000),
(39, 434343, 0, 434343),
(40, 11111, 0, 11111),
(41, 50000, 0, 50000),
(42, 9000, 0, 9000),
(43, 50000, 0, 50000),
(44, 22243, 0, 22243),
(45, 332323, 0, 332323),
(46, 10000, 0, 10000),
(47, 9000000, 0, 9000000),
(48, 343444444, 0, 343444444),
(49, 222222, 0, 222222),
(50, 33200, 0, 33200),
(51, 44444, 0, 44444),
(52, 900000, 0, 900000),
(53, 3333333, 0, 3333333),
(54, 8999, 0, 8999),
(55, 9000, 0, 9000),
(56, 43330, 0, 43330),
(57, 8900, 0, 8900),
(58, 20000, 0, 20000),
(59, 4440, 0, 4440),
(60, 2134, 0, 2134),
(61, 7799, 0, 7799),
(62, 7899, 0, 7899),
(64, 7777, 0, 7777),
(65, 60000, 0, 60000),
(66, 30000, 0, 30000),
(67, 80900, 0, 80900),
(68, 9090, 0, 9090),
(69, 10900, 0, 10900),
(70, 67333, 0, 67333),
(71, 90000, 0, 90000),
(72, 22222, 0, 22222),
(73, 9333, 0, 9333),
(74, 3334, 0, 3334),
(75, 933, 0, 933),
(76, 3332, 0, 3332),
(77, 43433, 0, 43433),
(78, 77777, 0, 77777),
(79, 2222, 0, 2222),
(80, 5555, 0, 5555),
(81, 9000, 0, 9000),
(82, 10900, 0, 10900),
(83, 1222, 0, 1222),
(84, 65432, 0, 65432),
(85, 12344, 0, 12344),
(86, 22222, 0, 22222),
(87, 50000, 0, 50000),
(88, 9900, 0, 9900),
(89, 8930, 0, 8930),
(90, 2322, 0, 2322),
(91, 34321, 0, 34321),
(92, 3432, 0, 3432),
(93, 32221, 0, 32221),
(94, 32242, 0, 32242),
(95, 2221, 0, 2221),
(96, 43543, 0, 43543),
(97, 84932, 0, 84932),
(98, 2333, 0, 2333),
(99, 3222, 0, 3222),
(100, 21215, 0, 21215),
(101, 12345, 0, 12345),
(102, 0, 0, 0),
(103, 3332, 0, 3332),
(104, 2200, 0, 2200),
(105, 90900, 0, 90900),
(106, 8888, 0, 8888),
(107, 10101, 0, 10101),
(108, 99092, 0, 99092),
(109, 43432, 0, 43432),
(110, 24232, 0, 24232),
(111, 7853, 0, 7853),
(112, 9800, 0, 9800),
(113, 90930, 0, 90930),
(114, 80900, 0, 80900),
(115, 43433, 0, 43433),
(116, 3422, 0, 3422),
(117, 8933, 0, 8933),
(118, 6000, 0, 6000),
(119, 2211, 0, 2211),
(120, 4222, 0, 4222),
(121, 9999, 0, 9999),
(122, 4490, 0, 4490),
(123, 3321, 0, 3321),
(124, 9999, 0, 9999),
(125, 6000, 0, 6000),
(126, 5555, 0, 5555),
(127, 9999, 0, 9999),
(128, 43430, 0, 43430),
(129, 32324, 0, 32324),
(130, 8999, 0, 8999),
(131, 3433, 0, 3433),
(132, 4342, 0, 4342),
(133, 8199, 0, 8199),
(134, 33990, 0, 33990),
(135, 3422, 0, 3422),
(136, 4335, 0, 4335),
(137, 5449, 0, 5449),
(138, 23231, 0, 23231),
(139, 2323, 0, 2323),
(140, 2322, 0, 2322),
(141, 2213, 0, 2213),
(142, 2342, 0, 2342),
(143, 3212, 0, 3212),
(144, 3432, 0, 3432),
(145, 3333, 0, 3333),
(146, 4532, 0, 4532),
(147, 24111, 0, 24111),
(148, 9911, 0, 9911),
(149, 3432, 0, 3432),
(150, 4533, 0, 4533),
(151, 4444, 0, 4444),
(152, 3214, 0, 3214),
(153, 4332, 0, 4332),
(154, 43242, 0, 43242),
(155, 32423, 0, 32423),
(156, 8899, 0, 8899),
(157, 2321, 0, 2321),
(158, 9999, 0, 9999),
(159, 6533, 0, 6533),
(160, 2324, 0, 2324),
(161, 2345, 0, 2345),
(162, 77654, 0, 77654),
(163, 8998, 0, 8998),
(164, 34242, 0, 34242),
(165, 32432, 0, 32432),
(166, 4322, 0, 4322),
(167, 5432, 0, 5432),
(168, 79879, 0, 79879),
(169, 7886, 0, 7886),
(170, 7908, 0, 7908),
(171, 5232, 0, 5232),
(172, 2323, 0, 2323),
(173, 32142, 0, 32142),
(174, 2323, 0, 2323),
(175, 8987, 0, 8987),
(176, 34234, 0, 34234),
(177, 4232, 0, 4232),
(178, 3242, 0, 3242),
(179, 9999, 0, 9999),
(180, 4234, 0, 4234),
(181, 4322, 0, 4322),
(182, 5411, 0, 5411),
(183, 3214, 0, 3214),
(184, 4322, 0, 4322),
(185, 4322, 0, 4322),
(186, 32234, 0, 32234),
(187, 33332, 0, 33332),
(188, 4322, 0, 4322),
(189, 2343, 0, 2343),
(190, 3242, 0, 3242),
(191, 32111, 0, 32111),
(192, 9993, 0, 9993),
(193, 9322, 0, 9322),
(194, 24242, 0, 24242),
(195, 8888, 0, 8888),
(196, 4999, 0, 4999),
(197, 78987, 0, 78987),
(198, 90809, 0, 90809),
(199, 43252, 0, 43252),
(200, 99888, 0, 99888),
(201, 35522, 0, 35522),
(202, 5535, 0, 5535),
(203, 5432, 0, 5432),
(204, 3222, 0, 3222),
(205, 9999, 0, 9999),
(206, 4143, 0, 4143),
(207, 8997, 0, 8997),
(208, 12334, 0, 12334);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alogin`
--
ALTER TABLE `alogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `employee_leave`
--
ALTER TABLE `employee_leave`
  ADD PRIMARY KEY (`token`),
  ADD KEY `employee_leave_ibfk_1` (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `project_ibfk_1` (`eid`);

--
-- Indexes for table `rank`
--
ALTER TABLE `rank`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alogin`
--
ALTER TABLE `alogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT for table `employee_leave`
--
ALTER TABLE `employee_leave`
  MODIFY `token` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee_leave`
--
ALTER TABLE `employee_leave`
  ADD CONSTRAINT `employee_leave_ibfk_1` FOREIGN KEY (`id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project`
--
ALTER TABLE `project`
  ADD CONSTRAINT `project_ibfk_1` FOREIGN KEY (`eid`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rank`
--
ALTER TABLE `rank`
  ADD CONSTRAINT `rank_ibfk_1` FOREIGN KEY (`eid`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salary`
--
ALTER TABLE `salary`
  ADD CONSTRAINT `salary_ibfk_1` FOREIGN KEY (`id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
