Free Download Source Code "Employee Management System"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"Employee_Management_System"

4. Download the zip file/ download winrar

5. Extract the file and copy "Employee_Management_System" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name ems

6. Import ems.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/Employee_Management_System


**LOGIN DETAILS** 

Admin
user: admin@gmail.com
pass: admin

User
user: john@gmail.com
pass: 1234

****** https:1sourcecodr.blogspot.com ******
Subcribe my You tube Channel **** 1 Source code ****